# Daily-Journal


  Daily Journal | Self project                                                                                                                                                                                            (Autumn 2021)

   Objective: To create a blogging platform with a simple and clean UI

•  With read and write functionality of the blog on the website, also a clean and easy to use user interface

•  Used HTML, CSS, and Javascript for front-end of the web application and deployed it on Heroku

•  Used Node.js with Express.js and EJS for back-end development and MongoDB for database management 
